var conf = require("./conf");

var frameModule = require('ui/frame'); 
var timerModule = require("timer");

var Model = require("./all-model");

var dialogsModule = require("tns-core-modules/ui/dialogs");

var ClassModel = new Model([]);
var context, navData;

//onloaded
exports.onLoaded = function(args){
    var page = args.object;
    context = ClassModel;
    page.bindingContext = context;
};

//tap savedata
exports.saveData = function(){
    let data = {
        name : context.name,
        phone : context.phone,
        description : context.description
    };
    // save data
    ClassModel.addData(data).then(function(result){
        //jika sukses tampil alert
        if(result.success ){
            dialogsModule.alert(
            {
                title: "Success",
                message: result.message,
                okButtonText: "Ok"
            });
            frameModule.topmost().goBack();
        } else{
            dialogsModule.alert(
            {
                title: "Alert",
                message: "Error Occured!",
                okButtonText: "Ok"
            });
        }
    })
};

exports.moveMainPage = function(){
    timerModule.setTimeout(
        function(){
            let navOption = {
                moduleName: "list",
                animated: true,
                transition: {
                    duration: conf.transduration,
                    curve: conf.curve,
                    name: "slideRight"
                }
            };
            frameModule.topmost().navigate(navOption);
        },conf.timeloader);
};