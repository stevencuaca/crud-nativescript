module.exports= {
    domain:"https://stevencuaca-tugasku.000webhostapp.com/",
    timeloader:100,
    transduration:200,
    curve:"linear"
    };