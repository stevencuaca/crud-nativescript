<?php
    function db($params = array()){
        // cek hostname
        if(isset($params['hostname'])){
            $hostname = $params['hostname'];
        } else{
            $hostname = "localhost";
        }
        // cek username
        if(isset($params['username'])){
            $username = $params['username'];
        } else{
            $username = "yourusername";
        }
        // cek password
        if(isset($params['password'])){
            $password = $params['password'];
        } else{
            $password = "yourpassword";
        }
        // database
        if(isset($params['database'])){
            $database = $params['database'];
        } else{
            $database = "yourdatabase";
        }
        // koneksi
        $koneksi = new mysqli($hostname, $username, $password, $database);
        // jika error
        if($koneksi->connect_error){
            die("Connection failed". $koneksi->connect_error);
        }
        // kembalikan hasil
        return $koneksi;
    };

    function query_get($sql = null){
        $db = db(); // ambil data dari function db
        if($sql === null){
            return null;
        } else{
            if($result = $db->query($sql)){
                $data = [];
                //loop
                while($row = $result->fetch_assoc()){
                    $data[] = $row;
                }

                return $data;
                $return->free();
            }
            $db->close();
        }
    };
    
    // digunakan untuk insert, update, delete
    function query_raw($sql = null){
        $db = db();
        if($sql === null){
            return null;
        } else{
            if($result = $db->query($sql)){
                return $result;
                $result->free();
            }
            $db-close();
        }
    }
?>